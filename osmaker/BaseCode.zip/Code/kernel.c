int ch;

#define WHITE_TXT 0x07

void k_clear_screen();
unsigned int k_printf(char *message, unsigned int line);
typedef struct __attribute__ ((packed)) {
    unsigned short di, si, bp, sp, bx, dx, cx, ax;
    unsigned short gs, fs, es, ds, eflags;
} regs16_t;
extern void int32(unsigned char intnum, regs16_t *regs);
void k_memset(char *address, int value, int size) {
    char *p = address;
    for (int i = 0; i < size; i++) {
        *p++ = value;
    }
}

void k_main() 
{

    regs16_t regs;
     


};

void k_clear_screen()
{
	char *vidmem = (char *) 0xb8000;
	unsigned int i=0;
	while(i < (80*25*2))
	{
		vidmem[i]=' ';
		i++;
		vidmem[i]=WHITE_TXT;
		i++;
	};
};

unsigned int k_printf(char *message, unsigned int line)
{
	char *vidmem = (char *) 0xb8000;
	unsigned int i=0;

	i=(line*80*2) + ch;

	while(*message!=0)
	{
		if(*message=='\n')
		{
			line++;
			i=(line*80*2);
			*message++;
			ch = 0;
		} else {
			vidmem[i]=*message;
			*message++;
			i++;
			vidmem[i]=WHITE_TXT;
			i++;
			ch += 2;
		};
	};

	return(1);
}

void k_drawVline(int X,int Y1,int Y2,int Color)
{

	for(int y = Y1; y < Y2; y++)
        k_memset((char *)0xA0000 + (y*320+X), Color, 1);

}

void k_drawRect(int X,int Y,int widht,int height,int color)
{

	for(int x = X; x < X + widht; x++)
	{

		k_drawVline(x,Y,Y+height,color);

	}

}
void k_InitVGA(regs16_t regs,int Color)
{
	regs.ax = 0x0013;
    int32(0x10, &regs);
	k_memset((char *)0xA0000, Color, (320*200));

}
void k_textmode(regs16_t regs)
{

    regs.ax = 0x0003;
    int32(0x10, &regs);

}
void k_readkey(regs16_t regs)
{

    regs.ax = 0x0000;
    int32(0x16, &regs);

}